<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dominioncard";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT image FROM cards";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<br> img: ". $row["image"]. " <br>";
    }
} else {
    echo "0 results";
}?>
<script type="text/javascript">

</script>

<?php
$conn->close();
?>
