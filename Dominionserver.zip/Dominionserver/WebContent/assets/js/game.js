/**
 * Created by ThibauHaerinck on 24-3-2016.
 */
var openlightbox = function(e){
    e.preventDefault();
    var image_src = $(this).attr("src");
    var lightbox =
        '<div class="lightbox">' +
        '<div id="content">' +
        '<img src="' + image_src +'" />' +
        '</div>' +
        '</div>';
    $('body').append(lightbox);
    $(".lightbox").on('click',sluitlightbox);
};
var sluitlightbox = function(){
    $(".lightbox").remove();
};

var pausebox = function(e){
    e.preventDefault();
    var pausebox =
        '<div id="pausebox" class="lightbox">' +
        '<ol>'+
        '<li><p id="resume">Resume game</p></li>'+
        '<li><p>save game</p></li>'+
        '<li><a href="../index.html">Exit game</a></li>'+
        '</ol>'+
        '</div>';
    $('body').append(pausebox);
    $('#resume').on('click', sluitlightbox);

};

var throwhanddekcards = function(e){
    e.preventDefault();
    var cardthrow = $(this).html();
    $(this).remove();
    $("#playedcards ul").append('<li>'+cardthrow+'</li>');

};

var switchplayer = function(e){
    $("#players #playerwachten").attr('id','playertijdelijk');
    $("#players #playeraanzet").attr('id','playerwachten');
    $("#players #playertijdelijk").attr('id', 'playeraanzet');
};


/*Plus bij kaarten*/
var Pluskaartentonen = function(){
    $('.plus').remove();
    var aantalcoints = $("#coins span").text();
    $(".tekopen ul li").each(function(){
        var aantalkaarten = ($("this").find("span").text());
        console.log(aantalkaarten);
        if (($("this").children("span").text()) <= aantalcoints) {
            $(this).append('<p class="plus">+</p>');
        }
    });
};

var handdekverkleinen = function(){
    var amountcards = $("#handdek ul li").length;
    if(amountcards>7){
        $("#handdek ul li").css("margin-left","-30px");
        $("#handdek ul li:first-child").css("margin-left","0px");
    }
    else{
        $("#handdek ul li").css("margin-left","0px");
    }
};

/*var kaartkopen = function(){
    var soortkaarturl =  $(this).parent().find('img').attr('src');
    var soortkaart= soortkaarturl.substring(soortkaarturl.lastIndexOf('/')+1)
    $("#handdek ul").append('<li class="card"><img src="'+soortkaarturl+'"/></li>');
}*/



$(document).ready(function(){
    $("header h2").html(localStorage.getItem('titlegame'));
    $("#kingdomcards ul li img, #victorycards ul li img, #treasurecards ul li img").on('click',openlightbox);
    $('#pause').on('click', pausebox);
    $("#handdek ul li").on('click',throwhanddekcards);
    $('#endturn').on('click',switchplayer);
    Pluskaartentonen();
    $('#handdek').on('click',handdekverkleinen);
    /*$('.plus').on('click',kaartkopen);*/


});