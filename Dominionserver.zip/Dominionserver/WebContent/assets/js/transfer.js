/**
 * Created by ThibauHaerinck on 25-3-2016.
 */
var title = function(){
    var selector = $(this).attr('data-id');
    var titleh2="";
    switch (selector) {
        case "fotoseerstespel":
             titleh2 = "First Game";
            break;
        case "fotosveelgeld":
            titleh2 = "Big Money";
            break;
        case "fotosinteractie":
            titleh2 = "Interaction";
            break;
        case "fotosvertekendbeeld":
            titleh2 = "Size Distortion";
            break;
        case "fotosdorpsplein":
            titleh2 = "Village Square";
            break;
        default:
            titleh2 = "No Game";
    }
};

$(document).ready(function(){

});
