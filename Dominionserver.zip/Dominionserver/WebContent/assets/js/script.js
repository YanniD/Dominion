/**
 * Created by ThibauHaerinck on 23-3-2016.
 */
var toonkaartenvanpreset = function(e){
    var selector = '#' + $(this).attr('data-id');
    $("ul li").removeClass();
    $(this).attr("class", "selected");
    $("aside").hide();
    $(selector).show();
};
var openlightbox = function(e){
    e.preventDefault();
    var image_src = $(this).attr("src");
    var lightbox =
        '<div id="lightbox">' +
        '<div id="content">' +
        '<img src="' + image_src +'" />' +
        '</div>' +
        '</div>';
    $('body').append(lightbox);
    $("#lightbox").on('click',sluitlightbox);
};
var sluitlightbox = function(){
    $("#lightbox").remove();
};


var setlocalstorrage = function(){
    var selector = $(".selected").attr('data-id');
    var titleh2="";
    switch (selector) {
        case "fotoseerstespel":
            titleh2 = "First Game";
            break;
        case "fotosveelgeld":
            titleh2 = "Big Money";
            break;
        case "fotosinteractie":
            titleh2 = "Interaction";
            break;
        case "fotosvertekendbeeld":
            titleh2 = "Size Distortion";
            break;
        case "fotosdorpsplein":
            titleh2 = "Village Square";
            break;
        default:
            titleh2 = "No Game";
    }
    localStorage.setItem('titlegame', titleh2);
};
$(document).ready(function(){
    $("ul li").on('click', toonkaartenvanpreset);
    $("aside img").on('click',openlightbox);
    $("#startgame").on('click', setlocalstorrage);
});